﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_X
{
    public partial class Form1 : Form
    {
        //вызывается класс случайных чисел
        //с образовванием переменной randomizer
        Random randomizer = new Random();
        // целочисленное 1 слагаемое
        int addend1;
        // целочисленное 2 слагаемое
        int addend2;
        // целочисленное уменьшаемое и вычитаемое 
        int minuend;
        int subtrahend;

        // целочисленный первый и второй множитель 
        int multiplicand;
        int multiplier;

        // целочисленные делимое и делитель
        int dividend;
        int divisor;

        int timeLeft;
        public Form1()
        {
            InitializeComponent();
        }
        public void StartTheQuiz()
        {
            // добавляем рандомные переменные с числами от 0 до 50
            addend1 = randomizer.Next(51);
            addend2 = randomizer.Next(51);

            // добавляем рандомные переменные в значения строк
            plusLeftLabel.Text = addend1.ToString();
            plusRightLabel.Text = addend2.ToString();

            // выводим сумму
            sum.Value = 0;

            // ограничиваем рандомность и выводим их в строки
            minuend = randomizer.Next(1, 101);
            subtrahend = randomizer.Next(1, minuend);
            minusLeftLabel.Text = minuend.ToString();
            minusRightLabel.Text = subtrahend.ToString();
            difference.Value = 0;

            // тоже самое, только с уамножением
            multiplicand = randomizer.Next(2, 11);
            multiplier = randomizer.Next(2, 11);
            timesLeftLabel.Text = multiplicand.ToString();
            timesRightLabel.Text = multiplier.ToString();
            product.Value = 0;

            // тоже самое и добавляем переменную
            // для того чтобы числа могли делиться
            divisor = randomizer.Next(2, 11);
            int temporaryQuotient = randomizer.Next(2, 11);
            dividend = divisor * temporaryQuotient;
            dividedLeftLabel.Text = dividend.ToString();
            dividedRightLabel.Text = divisor.ToString();
            quotient.Value = 0;
            // функция для таймера
            timeLeft = 30;
            timeLabel.Text = "30 секунд";
            timer1.Start();
        }

        private void startButton_Click(object sender, EventArgs e)
        {
            StartTheQuiz();
            startButton.Enabled = false;
        }
        // функция для таймера и различные действия по истечении времени
        // 
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (CheckTheAnswer())
            {
                // вывод если всё правильно
                timer1.Stop();
                MessageBox.Show("Вы правильно посчитали!",
                                "Поздравляем!");
                startButton.Enabled = true;
            }
            else if (timeLeft > 0)
            {
                // предупреждеие об окончании времени

              

                timeLeft = timeLeft - 1;
                if (timeLeft < 6)
                {
                    timeLabel.BackColor = Color.Red;
                }
                timeLabel.Text = timeLeft + " секунд";
            }
            else
            {
                // вывод если время закончилось
                timer1.Stop();
                timeLabel.Text = "Время истекло!";
                MessageBox.Show("Вы не успели.", "Извините!");
                sum.Value = addend1 + addend2;
                difference.Value = minuend - subtrahend;
                product.Value = multiplicand * multiplier;
                quotient.Value = dividend / divisor;
                startButton.Enabled = true;
            }
        }
        private bool CheckTheAnswer()
        {
            // проверка правильности ответов
            if ((addend1 + addend2 == sum.Value)
                && (minuend - subtrahend == difference.Value)
                && (multiplicand * multiplier == product.Value)
                && (dividend / divisor == quotient.Value))
                return true;
            else
                return false;
        }

        private void answer_Enter(object sender, EventArgs e)
        {
            // функция ввода ответов
            NumericUpDown answerBox = sender as NumericUpDown;

            if (answerBox != null)
            {
                int lengthOfAnswer = answerBox.Value.ToString().Length;
                answerBox.Select(0, lengthOfAnswer);

            }
        }

    }
}
